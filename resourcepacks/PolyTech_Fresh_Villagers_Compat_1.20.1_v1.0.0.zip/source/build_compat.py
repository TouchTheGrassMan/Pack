#!/usr/bin/env python3
"""Build the targeted FA 1.10.4 / Nyf's Genetics 1.0.2 compatibility pack.

Requires Python 3.10+ and Pillow. Original JARs/ZIP are read-only inputs.
Usage: python build_compat.py INPUT_DIRECTORY OUTPUT_DIRECTORY
"""
from __future__ import annotations

import copy
import hashlib
import io
import json
import sys
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

from PIL import Image

VERSION = "1.0.0"
PACK_NAME = f"PolyTech_Fresh_Villagers_Compat_1.20.1_v{VERSION}"
TRANSPARENT = (0, 0, 0, 0)
CEM = "assets/minecraft/optifine/cem/"
NYF = "assets/nyfsgenetics/textures/entity/villager/"
SKIN_COLORS = {
    (190, 136, 108, 255), (183, 130, 114, 255),
    (179, 123, 98, 255), (117, 71, 47, 255),
    (144, 94, 67, 255), (181, 123, 103, 255),
    (163, 107, 77, 255),
}


def read_image(z, name):
    return Image.open(io.BytesIO(z.read(name))).convert("RGBA")


def png_bytes(im):
    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    return buf.getvalue()


def json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def choose(folder, pattern):
    candidates = sorted(folder.glob(pattern))
    if len(candidates) != 1:
        raise ValueError(f"Expected one file matching {pattern}, found {candidates}")
    return candidates[0]


def adapt_model(original):
    data = copy.deepcopy(original)
    head = next(m for m in data["models"] if m.get("part") == "head")
    nose = next(m for m in data["models"] if m.get("part") == "nose")
    assert nose["translate"] == [0, -24, 0]
    assert len(nose["boxes"]) == 1
    assert {m["id"] for m in nose["submodels"]} == {"nose2", "face"}

    # The skin, eyes, brows, and mouth belong to the head, not the gene-scaled
    # vanilla nose. Preserve the original CEM coordinates and local transform.
    face_group = {
        "id": "polytech_genetic_head",
        "invertAxis": nose["invertAxis"],
        "translate": copy.deepcopy(nose["translate"]),
        "boxes": nose.pop("boxes"),
        "submodels": [m for m in nose["submodels"] if m["id"] == "face"],
    }
    head.setdefault("submodels", []).append(face_group)
    nose["submodels"] = [m for m in nose["submodels"] if m["id"] == "nose2"]

    # Vanilla/Nyf's normal nose pivot is Y=-2. Original FA forces it to zero.
    # +2 CEM-local Y compensates for restoring that vanilla pivot. The small
    # and long genes now act on exactly the same unanimated box as vanilla.
    nose["translate"][1] = -26
    return data


def adapt_animations(original):
    data = copy.deepcopy(original)
    removed = 0
    for animation in data["animations"]:
        if "nose.ty" in animation:
            assert str(animation.pop("nose.ty")) == "0"
            removed += 1
    assert removed == 1
    return data


def palette_for(normal, variant):
    counts = defaultdict(Counter)
    for src, dst in zip(normal.get_flattened_data(), variant.get_flattened_data()):
        if src[3]:
            counts[src][dst] += 1
    # albinism_villager has six baked-in brow pixels; the majority mapping
    # deliberately ignores them. Brows are controlled by the genetic layer.
    return {src: counter.most_common(1)[0][0] for src, counter in counts.items()}


def adapt_skin(normal, variant, fa):
    palette = palette_for(normal, variant)
    anchor = (179, 123, 98, 255)
    delta = tuple(palette[anchor][i] - anchor[i] for i in range(3))
    result = fa.copy()
    for y in range(64):
        for x in range(64):
            color = fa.getpixel((x, y))
            if not color[3]:
                result.putpixel((x, y), TRANSPARENT)
            elif 13 <= x < 21 and 19 <= y < 21:
                # No default brow underneath a genetic NONE/DOUBLE brow.
                result.putpixel((x, y), TRANSPARENT)
            elif color in palette:
                result.putpixel((x, y), palette[color])
            else:
                # FA introduces one neutral eyelid shade absent in vanilla.
                assert color == (157, 105, 82, 255), (x, y, color)
                result.putpixel((x, y), tuple(max(0, min(255, color[i] + delta[i]))
                                             for i in range(3)) + (255,))
    return result


def adapt_eyes(original):
    result = Image.new("RGBA", original.size, TRANSPARENT)
    # Green is an intentionally empty override in Nyf's; green is already
    # present in the base skin's pupil atlas. Preserve that convention.
    for old, new in [((10, 14), (15, 21)), ((13, 14), (18, 21))]:
        result.putpixel(new, original.getpixel(old))
    return result


def adapt_brows(original, no_brows=False):
    result = Image.new("RGBA", original.size, TRANSPARENT)
    # Some NONE textures are skin-colored erasers for the old flat face.
    # They must not become moving skin-colored brow quads in the FA atlas.
    if not no_brows:
        result.paste(original.crop((8, 12, 16, 14)), (13, 19))
    return result


def adapt_chef(original):
    result = original.copy()
    removed = 0
    for y in range(22, 46):
        for x in range(40, 64):
            if original.getpixel((x, y)) in SKIN_COLORS:
                result.putpixel((x, y), TRANSPARENT)
                removed += 1
    return result, removed


def build(folder, output):
    sources = {
        "fresh_animations": choose(folder, "FreshAnimations_v1.10.4*.zip"),
        "nyfsgenetics": choose(folder, "nyfsgenetics-forge-1.20.1-1.0.2.jar"),
        "chefsdelight": choose(folder, "chefsdelight-1.0.4-forge-1.20.1*.jar"),
        "guardvillagers": choose(folder, "guardvillagers-1.20.1-1.6.17.jar"),
    }
    packs = {key: zipfile.ZipFile(path) for key, path in sources.items()}
    files = {}
    for name in ["villager.jem", "villager2.jem", "villager_baby.jem", "villager_baby2.jem"]:
        files[CEM + name] = json_bytes(adapt_model(json.loads(packs["fresh_animations"].read(CEM + name))))
    for name in ["villager_animations.jpm", "villager2_animations.jpm"]:
        files[CEM + name] = json_bytes(adapt_animations(json.loads(packs["fresh_animations"].read(CEM + name))))

    normal = read_image(packs["nyfsgenetics"], NYF + "normal_villager.png")
    fa = read_image(packs["fresh_animations"], "assets/minecraft/textures/entity/villager/villager.png")
    for name in packs["nyfsgenetics"].namelist():
        if not name.startswith(NYF) or not name.endswith(".png"):
            continue
        image = read_image(packs["nyfsgenetics"], name)
        if name.endswith("_villager.png"):
            files[name] = png_bytes(adapt_skin(normal, image, fa))
        elif name.endswith("_eyes.png"):
            files[name] = png_bytes(adapt_eyes(image))
        elif name.endswith("_eyebrow.png"):
            files[name] = png_bytes(adapt_brows(image, Path(name).name.startswith("none_")))

    removed_skin = {}
    for mob in ["villager", "zombie_villager"]:
        for profession, hat in [("delightchef", "full"), ("delightcook", "partial")]:
            name = f"assets/chefsdelight/textures/entity/{mob}/profession/{profession}.png"
            result, removed = adapt_chef(read_image(packs["chefsdelight"], name))
            files[name] = png_bytes(result)
            files[name + ".mcmeta"] = json_bytes({"villager": {"hat": hat}})
            removed_skin[name] = removed

    files["pack.mcmeta"] = json_bytes({"pack": {
        "pack_format": 15,
        "description": "PolyTech: Fresh Villagers Compat 1.0.0\nFA 1.10.4 + Nyf's Genetics + Chef's Delight | MC 1.20.1",
    }})
    manifest = {
        "version": VERSION,
        "minecraft": "1.20.1",
        "target_from_user_log": {"forge": "47.4.10", "emf": "3.2.4", "etf": "7.1"},
        "game_client_tested": False,
        "sources": {key: {"filename": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                    for key, path in sources.items()},
        "chef_skin_pixels_removed": removed_skin,
        "guardvillagers": "Static code inspection: separate HumanoidModel and 128x128 textures; no guard assets overridden.",
        "resources": {name: hashlib.sha256(content).hexdigest() for name, content in sorted(files.items())},
    }
    files["source/build_compat.py"] = Path(__file__).read_bytes()
    files["source/manifest.json"] = json_bytes(manifest)
    readme = Path(__file__).with_name("README_RU.txt")
    if readme.exists():
        files["README_RU.txt"] = readme.read_bytes()
    for extra in ["validate_compat.py", "VALIDATION.txt"]:
        path = Path(__file__).with_name(extra)
        if path.exists():
            files["source/" + extra] = path.read_bytes()

    output.mkdir(parents=True, exist_ok=True)
    archive = output / (PACK_NAME + ".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 9, 26, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, content)
    print(json.dumps({"archive": str(archive.resolve()), "entries": len(files),
                      "size": archive.stat().st_size, "chef_skin_pixels_removed": removed_skin}, indent=2))
    return archive


if __name__ == "__main__":
    build(Path(sys.argv[1] if len(sys.argv) > 1 else "upload"),
          Path(sys.argv[2] if len(sys.argv) > 2 else "output"))
