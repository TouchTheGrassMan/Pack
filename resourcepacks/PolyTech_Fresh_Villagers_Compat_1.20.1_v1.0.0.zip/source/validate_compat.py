#!/usr/bin/env python3
"""Static regression checks; does NOT claim an in-game render test.

python validate_compat.py ORIGINAL_ARCHIVE_DIRECTORY PATCH_ZIP
Requires Pillow and numpy. It checks geometry after vanilla gene transforms,
texture layer composition, unchanged animations, and input checksums.
"""
import copy
import hashlib
import io
import json
import sys
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image

CEM = "assets/minecraft/optifine/cem/"
NYF = "assets/nyfsgenetics/textures/entity/villager/"
GENES = {
    "NORMAL": (-2, 0, 1, 1, True),
    "SMALL": (-3, 0, .5, 1, True),
    "LONG": (-3, 4, .5, 2, True),
    "NONE": (-2, 0, 1, 1, False),
}


def image(z, n):
    return Image.open(io.BytesIO(z.read(n))).convert("RGBA")


def transform(translation=(0, 0, 0), scales=(1, 1, 1), rotation=(0, 0, 0)):
    m = np.eye(4)
    m[:3, 3] = translation
    for axis in [2, 1, 0]:
        a = np.deg2rad(rotation[axis])
        c, s = np.cos(a), np.sin(a)
        r = np.eye(4)
        i, j = [(1, 2), (2, 0), (0, 1)][axis]
        r[i, i] = r[j, j] = c
        r[i, j] = -s
        r[j, i] = s
        m = m @ r
    return m @ np.diag([*scales, 1])


def geometry(model, gene, original_fa=False):
    """Interpret CEM transforms attached to the known vanilla head/nose bones.

    Box vertices are independent from the patch-generation code. Animation
    rotations are zero for the neutral-pose regression; original FA's
    explicit nose.ty=0 is applied exactly as in its JPM.
    """
    y, z, sy, sz, visible = GENES[gene]
    collected = {}

    def walk(node, parent):
        inv = node.get("invertAxis", "")
        sign = [-1 if c in inv else 1 for c in "xyz"]
        t = np.array(node.get("translate", [0, 0, 0])) * sign
        r = np.array(node.get("rotate", [0, 0, 0])) * sign
        mat = parent @ transform(t, rotation=r)
        for i, box in enumerate(node.get("boxes", [])):
            pos = np.array(box["coordinates"][:3], dtype=float)
            size = np.array(box["coordinates"][3:], dtype=float)
            for a, s in enumerate(sign):
                if s == -1:
                    pos[a] = -pos[a] - size[a]
            corners = np.array([[*(pos + size * np.array([x, y, z])), 1]
                                for x in (0, 1) for y in (0, 1) for z in (0, 1)]).T
            points = (mat @ corners)[:3].T
            collected[(node.get("id"), i)] = np.array([points.min(0), points.max(0)])
        for child in node.get("submodels", []):
            walk(child, mat)

    for node in model["models"]:
        part = node.get("part")
        if part == "head":
            walk(node, np.eye(4))
        elif part == "nose" and visible:
            walk(node, transform((0, 0 if original_fa else y, z), (1, sy, sz)))
    return collected


def main(inputs, filename):
    patch = zipfile.ZipFile(filename)
    assert patch.testzip() is None
    assert len(patch.namelist()) == len(set(patch.namelist()))
    manifest = json.loads(patch.read("source/manifest.json"))
    originals = {}
    for key, value in manifest["sources"].items():
        p = inputs / value["filename"]
        assert hashlib.sha256(p.read_bytes()).hexdigest() == value["sha256"]
        originals[key] = zipfile.ZipFile(p)
    for name, digest in manifest["resources"].items():
        assert hashlib.sha256(patch.read(name)).hexdigest() == digest
    for name in patch.namelist():
        assert not name.startswith("/") and ".." not in Path(name).parts
        if name.endswith((".json", ".mcmeta", ".jem", ".jpm")):
            json.loads(patch.read(name))
        elif name.endswith(".png"):
            assert image(patch, name).size == (64, 64)
    assert json.loads(patch.read("pack.mcmeta"))["pack"]["pack_format"] == 15
    print("PASS: archive, JSON/PNG decoding, resource digests, original input hashes")

    fa = originals["fresh_animations"]
    geometry_cases = 0
    for basename in ["villager.jem", "villager2.jem", "villager_baby.jem", "villager_baby2.jem"]:
        name = CEM + basename
        before = json.loads(fa.read(name))
        after = json.loads(patch.read(name))
        original_geo = geometry(before, "NORMAL", True)
        expected_head = original_geo[("nose", 0)]
        assert np.allclose(expected_head, [[-4, -10, -4], [4, 0, 4]])
        for gene, (y, z, sy, sz, visible) in GENES.items():
            actual = geometry(after, gene)
            assert np.allclose(actual[("polytech_genetic_head", 0)], expected_head)
            for ident in ["r_eye_white", "l_eye_white", "r_pupil", "l_pupil", "brow", "mouth"]:
                assert np.allclose(actual[(ident, 0)], original_geo[(ident, 0)])
            if visible:
                # Vanilla nose cube (-1,-1,-6), size 2x4x2, transformed using
                # values independently read from Nyf's compiled mixin.
                expected_nose = [[-1, y - sy, z - 6 * sz], [1, y + 3 * sy, z - 4 * sz]]
                assert np.allclose(actual[("nose2", 0)], expected_nose)
            else:
                assert ("nose2", 0) not in actual
                assert ("polytech_genetic_head", 0) in actual
            geometry_cases += 1
        # Every unrelated model part must be byte-for-byte equivalent as JSON.
        for old, new in zip(before["models"], after["models"]):
            if old.get("part") not in {"head", "nose"}:
                assert old == new
        all_ids = []
        def collect(node):
            if "id" in node:
                all_ids.append(node["id"])
            if "model" in node:
                resource = CEM + node["model"]
                assert resource in patch.namelist() or resource in fa.namelist()
            for sub in node.get("submodels", []):
                collect(sub)
        for m in after["models"]:
            collect(m)
        assert len(all_ids) == len(set(all_ids))
    print(f"PASS: {geometry_cases} geometry cases; head/face stable for all nose genes; vanilla nose bounds preserved")

    for basename in ["villager_animations.jpm", "villager2_animations.jpm"]:
        before = json.loads(fa.read(CEM + basename))
        after = json.loads(patch.read(CEM + basename))
        expected = copy.deepcopy(before)
        for a in expected["animations"]:
            a.pop("nose.ty", None)
        assert after == expected
    print("PASS: original animations preserved except the conflicting nose Y reset")

    nyf = originals["nyfsgenetics"]
    skins = [n for n in patch.namelist() if n.startswith(NYF) and n.endswith("_villager.png")]
    brows = [n for n in patch.namelist() if n.startswith(NYF) and n.endswith("_eyebrow.png")]
    eyes = [n for n in patch.namelist() if n.startswith(NYF) and n.endswith("_eyes.png")]
    assert (len(skins), len(brows), len(eyes)) == (5, 19, 4)
    for name in brows:
        assert image(patch, name).crop((8, 12, 16, 14)).getbbox() is None
        if Path(name).name.startswith("none_"):
            assert image(patch, name).getbbox() is None
        else:
            assert image(patch, name).crop((13, 19, 21, 21)).tobytes() == image(nyf, name).crop((8, 12, 16, 14)).tobytes()
    for name in skins:
        im = image(patch, name)
        assert im.crop((8, 8, 16, 18)).getextrema()[3] == (255, 255)
        assert im.crop((13, 19, 21, 21)).getbbox() is None
        for x in [15, 18]:
            assert im.getpixel((x, 21)) == (0, 150, 17, 255)
        for x in [14, 15, 18, 19]:
            assert im.getpixel((x, 22)) == (255, 255, 255, 255)
        for x in [9, 10, 13, 14]:
            assert im.getpixel((x, 14)) not in {(255, 255, 255, 255), (0, 150, 17, 255)}
    compositions = 0
    for skin in skins:
        for eye in eyes:
            for brow in brows:
                composed = Image.alpha_composite(image(patch, skin), image(patch, eye))
                composed = Image.alpha_composite(composed, image(patch, brow))
                original_eye = image(nyf, eye).getpixel((10, 14))
                expected = original_eye if original_eye[3] else (0, 150, 17, 255)
                assert composed.getpixel((15, 21)) == expected
                if Path(brow).name.startswith("none_"):
                    assert composed.crop((13, 19, 21, 21)).getbbox() is None
                compositions += 1
    for n in nyf.namelist():
        if n.startswith(NYF) and n.endswith("_hair.png"):
            assert n not in patch.namelist()
            assert image(nyf, n).crop((13, 19, 21, 24)).getbbox() is None
    print(f"PASS: {compositions} skin/eye/brow layer combinations and unchanged hair UVs")

    chef = originals["chefsdelight"]
    for mob in ["villager", "zombie_villager"]:
        for profession, hat in [("delightchef", "full"), ("delightcook", "partial")]:
            name = f"assets/chefsdelight/textures/entity/{mob}/profession/{profession}.png"
            assert json.loads(patch.read(name + ".mcmeta")) == {"villager": {"hat": hat}}
            a, b = image(chef, name), image(patch, name)
            changes = 0
            for y in range(64):
                for x in range(64):
                    if a.getpixel((x, y)) != b.getpixel((x, y)):
                        assert 40 <= x < 64 and 22 <= y < 46
                        old = a.getpixel((x, y))
                        assert old[0] > old[1] > old[2]
                        assert b.getpixel((x, y)) == (0, 0, 0, 0)
                        changes += 1
            assert changes == (128 if profession == "delightchef" else 0)
    assert not any(n.startswith("assets/guardvillagers/") or n.endswith(".class") for n in patch.namelist())
    print("PASS: chef clothing retained; 4 hat metadata entries; 256 fixed skin pixels removed")
    print("PASS: Guard Villagers resources and all mod code untouched")
    print("LIMITATION: static validation only; Minecraft/Forge client was not launched.")


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
